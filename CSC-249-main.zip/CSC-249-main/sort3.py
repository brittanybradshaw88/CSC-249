thislist = ["banana", "Orange", "Kiwi", "cherry"]
thislist.reverse()
print(thislist)
