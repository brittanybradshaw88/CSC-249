lst=["kiran","arun","varun","kunnal","tiya","rhea" ]
print("Checking if kunnal exists in list")
exist_count = lst.count("kunnal")
if exist_count> 0:
   print("Yes, kunnal exists in list")
else:
   print("No, kunnal does not exists in list")
